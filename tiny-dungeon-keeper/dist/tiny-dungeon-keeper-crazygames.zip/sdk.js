
(function(){
  "use strict";
  var noop = function(){};
  window.Platform = {
    name: "crazygames",
    hasRewarded: false,
    loadingStart: noop,
    loadingStop: noop,
    ready: noop,
    gameplayStart: noop,
    gameplayStop: noop,
    happyTime: noop,
    interstitial: function(){ return Promise.resolve(); },
    rewarded: function(){ return Promise.resolve(false); }
  };
  // muting is identical everywhere, so it lives here
  window.Platform._mute = function(on){
    try{ if(window.Game) window.Game.mute(on); }catch(e){}
  };
  window.Platform._safe = function(fn, fallback){
    try{ return fn(); }catch(e){ return fallback; }
  };
})();

/* Docs: https://docs.crazygames.com/sdk/html5-v3/ */
Platform.name = "crazygames";
Platform.hasRewarded = true;

var CG = null, cgReady = false, cgInit = Promise.resolve();
// the player's "mute audio" setting on CrazyGames
var cgMute = function(settings){
  Platform._safe(function(){ if(settings && window.Game && window.Game.setSdkMute) window.Game.setSdkMute(!!settings.muteAudio); });
};
Platform._safe(function(){
  if(window.CrazyGames && window.CrazyGames.SDK){
    CG = window.CrazyGames.SDK;
    cgInit = Promise.resolve(CG.init()).then(function(){
      cgReady = true;
      // progress is saved with the CrazyGames Data Module (cloud save for logged-in players)
      if(CG.data && CG.data.getItem) Platform.storage = CG.data;
      cgMute(CG.game.settings);
      CG.game.addSettingsChangeListener(cgMute);
    }, function(){});
  }
});
// every SDK call waits for init() (SDK v3 rejects calls made before it)
Platform.whenReady = cgInit;
var cg = function(fn){ cgInit.then(function(){ if(cgReady) Platform._safe(fn); }); };
Platform.loadingStart  = function(){ cg(function(){ CG.game.loadingStart(); }); };
Platform.loadingStop   = function(){ cg(function(){ CG.game.loadingStop(); }); };
Platform.gameplayStart = function(){ cg(function(){ CG.game.gameplayStart(); }); };
Platform.gameplayStop  = function(){ cg(function(){ CG.game.gameplayStop(); }); };
Platform.happyTime     = function(){ cg(function(){ CG.game.happytime(); }); };

function cgAd(type){
  return new Promise(function(resolve){
    if(!CG || !cgReady || !CG.ad){ resolve(false); return; }
    var settled = false;
    var finish = function(ok){
      if(settled) return;
      settled = true;
      Platform._mute(false);
      resolve(ok);
    };
    try{
      CG.ad.requestAd(type, {
        adStarted:  function(){ Platform._mute(true); },
        adFinished: function(){ finish(true); },
        adError:    function(){ finish(false); }
      });
    }catch(e){ finish(false); }
    // never leave the player stuck if no callback ever fires
    setTimeout(function(){ finish(false); }, 30000);
  });
}
Platform.interstitial = function(){ return cgAd("midgame").then(function(){}); };
Platform.rewarded     = function(){ return cgAd("rewarded"); };
