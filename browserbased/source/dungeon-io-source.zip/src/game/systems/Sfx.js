/**
 * Synthesised sound effects — no audio files to ship, which keeps portal
 * builds small. Every voice is throttled so a screen of hits stays musical.
 */
export class Sfx {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.muted = false;
    this.last = new Map();
  }

  /** Browsers only allow audio after a user gesture. */
  unlock() {
    if (this.ctx) {
      this.ctx.resume?.();
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.5;
    this.master.connect(this.ctx.destination);
    const len = this.ctx.sampleRate * 0.5;
    this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.5;
  }

  _ok(key, gap) {
    if (!this.ctx || this.muted) return false;
    const now = this.ctx.currentTime;
    if (now - (this.last.get(key) ?? -1) < gap) return false;
    this.last.set(key, now);
    return true;
  }

  _tone(freq, dur, { type = 'sine', gain = 0.2, slide = 1, delay = 0 } = {}) {
    const c = this.ctx;
    const t = c.currentTime + delay;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  _noise(dur, { freq = 1200, q = 1, gain = 0.2, type = 'bandpass', slide = 1 } = {}) {
    const c = this.ctx;
    const t = c.currentTime;
    const s = c.createBufferSource();
    s.buffer = this.noise;
    const f = c.createBiquadFilter();
    f.type = type;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(40, freq * slide), t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t);
    s.stop(t + dur + 0.02);
  }

  cast(kind) {
    if (!this._ok('cast', 0.09)) return;
    if (kind === 'zone') this._noise(0.35, { freq: 400, slide: 3, gain: 0.12 });
    else this._noise(0.22, { freq: 2400, slide: 0.4, gain: 0.1, q: 2 });
  }

  kill() {
    if (!this._ok('kill', 0.04)) return;
    this._tone(220 + Math.random() * 80, 0.08, { type: 'triangle', gain: 0.06, slide: 0.5 });
  }

  gem(combo) {
    if (!this._ok('gem', 0.03)) return;
    const step = Math.min(combo, 24);
    this._tone(660 * Math.pow(2, step / 24), 0.07, { type: 'sine', gain: 0.07 });
  }

  levelUp() {
    if (!this._ok('lvl', 0.2)) return;
    [523, 659, 784, 1046].forEach((f, k) => this._tone(f, 0.25, { type: 'triangle', gain: 0.12, delay: k * 0.07 }));
  }

  hurt() {
    if (!this._ok('hurt', 0.15)) return;
    this._tone(160, 0.18, { type: 'sawtooth', gain: 0.12, slide: 0.5 });
  }

  heal() {
    if (!this._ok('heal', 0.1)) return;
    this._tone(440, 0.3, { type: 'sine', gain: 0.12, slide: 2 });
  }

  magnet() {
    if (!this._ok('mag', 0.1)) return;
    this._tone(300, 0.5, { type: 'sine', gain: 0.12, slide: 3 });
  }

  chest() {
    if (!this._ok('chest', 0.2)) return;
    [392, 523, 659, 784, 988, 1175].forEach((f, k) => this._tone(f, 0.3, { type: 'square', gain: 0.05, delay: k * 0.06 }));
  }

  warn() {
    if (!this._ok('warn', 0.3)) return;
    this._tone(110, 0.5, { type: 'sawtooth', gain: 0.08, slide: 1.5 });
  }

  slam() {
    if (!this._ok('slam', 0.2)) return;
    this._noise(0.6, { freq: 300, type: 'lowpass', gain: 0.4, slide: 0.3 });
    this._tone(60, 0.5, { type: 'sine', gain: 0.35, slide: 0.5 });
  }

  boss() {
    if (!this._ok('boss', 1)) return;
    [98, 92, 87].forEach((f, k) => this._tone(f, 0.7, { type: 'sawtooth', gain: 0.1, delay: k * 0.35 }));
  }

  click() {
    if (!this._ok('click', 0.05)) return;
    this._tone(880, 0.05, { type: 'square', gain: 0.05 });
  }
}
